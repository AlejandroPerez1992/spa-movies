import React from 'react';

const Detalles = ({ pelicula }) => {

    const {  title, poster_path, original_title, id, backdrop_path } = pelicula;
    return ( 
        <div className ="col s15 m6 l3">
            <div className="card">
                <div className="card-image">
                    <img src= { "//image.tmdb.org/t/p/w300_and_h450_bestv2" + poster_path } alt="Imagen No Disponible"></img>
                    <h5>titulo : { title  }</h5>
                </div>
                <div className="card-image">
                    <img src= { "//image.tmdb.org/t/p/w300_and_h450_bestv2" + backdrop_path } alt="Imagen No Disponible"></img>
                    <h5> titulo original: { original_title  }</h5>
                </div>
            </div>
        </div>
     );
};
export default Detalles;