import React from 'react';
import Detalles from './Detalles';

const test=(param)=>{
    console.log(param);
};
const Pelicula = ({ pelicula }) => {

    const {  title, poster_path, original_title, id, backdrop_path } = pelicula;
    return ( 
        <div className ="col s15 m6 l3">
            <div className="card">
                <div className="card-image">
                    <img src= { "//image.tmdb.org/t/p/w300_and_h450_bestv2" + poster_path } alt="Imagen No Disponible"></img>
                    <h5>{ title  }</h5>
                        <Detalles
                            key={ pelicula.id }
                            pelicula={ pelicula }
                        />                      
                </div>
            </div>
            <button class="btn btn-primary" onClick={test('loco')}>Details</button>
        </div>
     );
};


export default Pelicula;
